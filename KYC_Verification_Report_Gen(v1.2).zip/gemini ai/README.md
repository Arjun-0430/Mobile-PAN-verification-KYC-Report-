# GEN-AI Application

This project is a simple web application that mimics the functionality of the provided GEN-AI application link. It allows users to input a name and mobile number, and then displays mock KYC data. The results can be downloaded as a PDF.

## How it Works

The application is built with a simple frontend and a Python Flask backend.

### Frontend

- **`index.html`**: This is the main page of the application. It contains the form for user input and the structure for displaying the results. It also includes the `jspdf` library for generating PDFs.
- **`style.css`**: This file contains the styles for the application, making it visually similar to the provided link.
- **`script.js`**: This file contains the logic for the frontend.
    - It handles the tab switching functionality.
    - It captures the form submission, sends a request to the backend, and then processes the response.
    - The received data is then formatted and displayed in a user-friendly format.
    - The `downloadPDF()` function uses the `jspdf` library to generate a PDF of the results.

### Backend

- **`app.py`**: This is a simple Flask application that serves the frontend and provides a mock API endpoint.
    - The `@app.route('/')` route serves the `index.html` file.
    - The `@app.route('/api/pan/mobile-to-pan', methods=['POST'])` route mimics the Surepass API. It receives the user's input, but instead of calling the actual API, it returns a hardcoded JSON response with dummy data. This is because we don't have a valid API token.
    - The application runs on `http://127.0.0.1:5001`.

## How to Run

1.  **Install Dependencies**:
    ```bash
    pip install Flask Flask-Cors
    ```
2.  **Run the Backend Server**:
    ```bash
    python app.py
    ```
3.  **Open the Application**:
    Open your web browser and navigate to `http://127.0.0.1:5001`.