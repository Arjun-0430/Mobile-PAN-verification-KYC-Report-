function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablink");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

document.getElementById("pan-to-mobile-form").addEventListener("submit", function(event) {
    event.preventDefault();
    const name = document.getElementById("name").value;
    const mobile_no = document.getElementById("mobile_no").value;

    fetch('/api/pan/mobile-to-pan', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, mobile_no }),
    })
    .then(response => response.json())
    .then(data => {
        const resultsDiv = document.getElementById("pan-to-mobile-results");
        resultsDiv.innerHTML = ''; // Clear previous results

        if (data.success) {
            const prefill = data.data.prefill_details;
            const pan = data.data.pan_details.pan_details;

            resultsDiv.innerHTML += `<h2>Prefill Details</h2>`;
            resultsDiv.innerHTML += `<p><b>Name:</b> ${prefill.name}</p>`;
            resultsDiv.innerHTML += `<p><b>Mobile:</b> ${prefill.mobile}</p>`;

            resultsDiv.innerHTML += `<h3>Personal Info</h3>`;
            resultsDiv.innerHTML += `<p><b>Full Name:</b> ${prefill.personal_info.full_name}</p>`;
            resultsDiv.innerHTML += `<p><b>DOB:</b> ${prefill.personal_info.dob}</p>`;
            resultsDiv.innerHTML += `<p><b>Gender:</b> ${prefill.personal_info.gender}</p>`;
            resultsDiv.innerHTML += `<p><b>Total Income:</b> ${prefill.personal_info.total_income}</p>`;
            resultsDiv.innerHTML += `<p><b>Age:</b> ${prefill.personal_info.age}</p>`;

            resultsDiv.innerHTML += `<h3>Phone Info</h3>`;
            prefill.phone_info.forEach(phone => {
                resultsDiv.innerHTML += `<p><b>Number:</b> ${phone.number} (Type: ${phone.type_code}, Reported: ${phone.reported_date})</p>`;
            });

            resultsDiv.innerHTML += `<h3>Address Info</h3>`;
            prefill.address_info.forEach(addr => {
                resultsDiv.innerHTML += `<p>${addr.address}, ${addr.state} - ${addr.postal} (Type: ${addr.type}, Reported: ${addr.reported_date})</p>`;
            });

            resultsDiv.innerHTML += `<h3>Email Info</h3>`;
            prefill.email_info.forEach(email => {
                resultsDiv.innerHTML += `<p><b>Email:</b> ${email.email_address} (Reported: ${email.reported_date})</p>`;
            });

            resultsDiv.innerHTML += `<h3>Identity Info</h3>`;
            resultsDiv.innerHTML += `<p><b>PAN:</b> ${prefill.identity_info.pan_number[0].id_number}</p>`;
            resultsDiv.innerHTML += `<p><b>Aadhaar:</b> ${prefill.identity_info.aadhaar_number[0].id_number}</p>`;


            resultsDiv.innerHTML += `<h2>PAN Details</h2>`;
            resultsDiv.innerHTML += `<p><b>PAN Number:</b> ${pan.pan_number}</p>`;
            resultsDiv.innerHTML += `<p><b>Full Name:</b> ${pan.full_name}</p>`;
            resultsDiv.innerHTML += `<p><b>Aadhaar Linked:</b> ${pan.aadhaar_linked}</p>`;
            resultsDiv.innerHTML += `<p><b>Status:</b> ${pan.status}</p>`;

            resultsDiv.innerHTML += `<button onclick="downloadPDF()">Download as PDF</button>`;
        } else {
            resultsDiv.innerHTML = `<p>Error: ${data.message}</p>`;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});

// Open the first tab by default
document.getElementsByClassName("tablink")[0].click();
function downloadPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    const results = document.getElementById('pan-to-mobile-results').innerText;
    doc.text(results, 10, 10);
    doc.save('report.pdf');
}