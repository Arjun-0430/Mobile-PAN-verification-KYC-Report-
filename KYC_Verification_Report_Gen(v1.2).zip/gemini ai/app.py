from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import json

app = Flask(__name__, static_folder='.', static_url_path='')
CORS(app)

@app.route('/')
def serve_index():
    return send_from_directory('.', 'index.html')

@app.route('/api/pan/mobile-to-pan', methods=['POST'])
def mobile_to_pan():
    # This is a mock response, as we don't have a real API key.
    # In a real application, you would make a request to the Surepass API here.
    data = {
    "data": {
        "client_id": "mobile_to_prefill_v3_ScLOIHCrrmxZAqBQNStN",
        "mobile_number": "7827234123",
        "prefill_details": {
            "client_id": "prefill_report_v2_IJlNQIhKhyCnkzgYkNRH",
            "name": "SATEESH SINGH",
            "mobile": "7827234123",
            "personal_info": {
                "full_name": "SATEESH SINGH ",
                "dob": "1994-11-02",
                "gender": "Male",
                "total_income": "30000",
                "occupation": None,
                "age": "30"
            },
            "phone_info": [
                {
                    "reported_date": "2025-05-15",
                    "type_code": "H",
                    "number": "6219698802"
                },
                {
                    "reported_date": "2025-01-31",
                    "type_code": "H",
                    "number": "7491102312"
                }
            ],
            "address_info": [
                {
                    "address": "MURHARIA KAIMUR BHABU",
                    "state": "BR",
                    "type": "Owns,Permanent",
                    "postal": "921102",
                    "reported_date": "2025-05-15"
                }
            ],
            "email_info": [
                {
                    "reported_date": "2025-01-31",
                    "email_address": "SATEESH123@GMAIL.COM"
                }
            ],
            "identity_info": {
                "pan_number": [
                    {
                        "id_number": "FYWPS1234M"
                    }
                ],
                "passport_number": [],
                "driving_license": [],
                "voter_id": [],
                "aadhaar_number": [
                    {
                        "id_number": "XXXXXXXXXXXX"
                    }
                ],
                "ration_card": [],
                "other_id": [
                    {
                        "id_number": "30065940967604"
                    }
                ]
            }
        },
        "pan_details": {
            "pan_status": "success",
            "pan_details": {
                "pan_number": "FYWPS1234M",
                "full_name": "SATEESH SINGH",
                "full_name_split": [
                    "SATEESH",
                    "SINGH"
                ],
                "masked_aadhaar": "XXXXXXXX2902",
                "address": {
                    "line_1": "",
                    "line_2": "",
                    "street_name": "",
                    "zip": "",
                    "city": "",
                    "state": "",
                    "country": "",
                    "full": ""
                },
                "email": None,
                "phone_number": None,
                "gender": "M",
                "dob": "1994-11-02",
                "input_dob": None,
                "aadhaar_linked": True,
                "dob_verified": False,
                "dob_check": False,
                "category": "person",
                "status": "valid",
                "less_info": False
            }
        },
        "status": "success"
    },
    "status_code": 200,
    "success": True,
    "message": "Success",
    "message_code": "success"
}
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True, port=5001)